create procedure updateOrderStatus(IN idorder int, IN idstatus int)
  BEGIN
update `order`
set id_status=idstatus
where id_order=idorder;
END;

